package io.customer.sdk.data.store

interface CustomerIOStore {
    val deviceStore: DeviceStore
}
