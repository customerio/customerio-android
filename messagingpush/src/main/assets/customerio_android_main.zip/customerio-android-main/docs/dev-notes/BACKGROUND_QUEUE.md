# Background queue

See [the iOS SDK doc](https://github.com/customerio/customerio-ios/blob/develop/docs/dev-notes/BACKGROUND-QUEUE.md) to maintain a single source of truth of this knowledge. 