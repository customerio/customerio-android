package io.customer.android.sample.kotlin_compose.ui.theme

import androidx.compose.ui.graphics.Color

val Purple40 = Color(0xFF3C437D)
val Green40 = Color(0xFF34C759)
val Pink40 = Color(0xFF7D5260)
