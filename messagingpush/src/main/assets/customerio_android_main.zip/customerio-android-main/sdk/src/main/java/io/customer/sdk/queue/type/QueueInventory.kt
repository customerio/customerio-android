package io.customer.sdk.queue.type

typealias QueueInventory = List<QueueTaskMetadata>
