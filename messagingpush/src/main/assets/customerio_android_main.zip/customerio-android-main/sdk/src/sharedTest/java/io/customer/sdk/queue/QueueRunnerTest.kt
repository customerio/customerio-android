package io.customer.sdk.queue

/**
 * Prefer to test this class via background queue integration tests as class is quite simple and is better tested via integration tests.
 */
class QueueRunnerTest
