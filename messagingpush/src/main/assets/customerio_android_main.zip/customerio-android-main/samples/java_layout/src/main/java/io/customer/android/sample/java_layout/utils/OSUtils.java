package io.customer.android.sample.java_layout.utils;

public class OSUtils {
    public static void restartApp() {
        System.exit(0);
    }
}
