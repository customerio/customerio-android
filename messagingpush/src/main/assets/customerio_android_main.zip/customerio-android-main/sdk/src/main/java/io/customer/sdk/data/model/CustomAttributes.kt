package io.customer.sdk.data.model

typealias CustomAttributes = Map<String, Any>
