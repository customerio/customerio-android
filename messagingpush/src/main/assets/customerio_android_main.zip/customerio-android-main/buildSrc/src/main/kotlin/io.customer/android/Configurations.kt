package io.customer.android

object Configurations {
    const val compileSdk = 33
    const val targetSdk = 30
    const val minSdk = 21
    const val artifactGroup = "io.customer.android"
}
